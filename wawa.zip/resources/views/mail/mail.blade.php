Hi, {{ $name }}

	Welcome to our Wa Wa Hotpot System! Thank you for giving your time .

	Here are the accounts for admin part and staff part for this system! you are allowed to access with these accounts!

	For Admin Account

	Email Account=>admin123@gmail.com
	Password=>123456789

	For Staff Account

	Email Account=>staff123@gmail.com
	Password=>123456789


	Since you get the accessable account and try again!
	
	Thank you so much for your time! Have fun!