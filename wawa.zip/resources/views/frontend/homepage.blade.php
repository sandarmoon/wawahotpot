@extends('frontend/front_template')

@section('content')

<div class="container-fluid bg-white">

		<div class="bg-white py-2 " id="curry-list">
			<div class="col-md-12 p-0">
				<div class="row m-0">

					@foreach($currys as $data)
						<div class="card shadow col-xl-2 col-md-3  mb-3 shadow p-0 menu-card" >
							<div>
								<img src="{{asset($data->photo)}}" class="card-img-top">
							</div>
							<div class="card-body text-center" style="padding: 5px;">
								<h4>{{$data->name}}</h4>
								<h4>Price: <span class="text-warning">{{$data->price}}K<span></h4>
								
							</div>
							<div class="card-footer bg-gradient-primary text-white addtocard" data-id="{{$data->id}}" data-name="{{$data->name}}" data-price="{{$data->price}}" data-photo="{{$data->photo}}" data-category="{{$data->category->name}}">
								<p class="text-center m-0"><a href="heo.html" onclick="return false;" class="text-white ">Add to Cart</a></p>
							</div>
						</div>

					@endforeach
					
				</div>
				
				
			</div>
		</div>

		<div class="bg-white py-2 d-none" id="meat-list">
			<div class="col-md-12 p-0">
				<div class="row m-0">

					@foreach($meats as $data)
						<div class="card shadow col-xl-2 col-md-3  mb-3 shadow p-0 menu-card" >
							<div>
								<img src="{{asset($data->photo)}}" class="card-img-top">
							</div>
							<div class="card-body text-center" style="padding: 5px;">
								<h4>{{$data->name}}</h4>
								<h4>Price: <span class="text-warning">{{$data->price}}K<span></h4>
								
							</div>
							<div class="card-footer bg-gradient-primary text-white addtocard" data-id="{{$data->id}}" data-name="{{$data->name}}" data-price="{{$data->price}}" data-photo="{{$data->photo}}" data-category="{{$data->category->name}}">
								<p class="text-center m-0"><a href="heo.html" onclick="return false;" class="text-white ">Add to Cart</a></p>
							</div>
						</div>

					@endforeach
					
				</div>
				
				
			</div>
		</div>

		<div class="bg-white py-2 d-none" id="seafood-list">
			<div class="col-md-12 p-0">
				<div class="row m-0">

					@foreach($seafoods as $data)
						<div class="card shadow col-xl-2 col-md-3  mb-3 shadow p-0 menu-card" >
							<div>
								<img src="{{asset($data->photo)}}" class="card-img-top">
							</div>
							<div class="card-body text-center" style="padding: 5px;">
								<h4>{{$data->name}}</h4>
								<h4>Price: <span class="text-warning">{{$data->price}}K<span></h4>
								
							</div>
							<div class="card-footer bg-gradient-primary text-white addtocard" data-id="{{$data->id}}" data-name="{{$data->name}}" data-price="{{$data->price}}" data-photo="{{$data->photo}}" data-category="{{$data->category->name}}">
								<p class="text-center m-0"><a href="heo.html" onclick="return false;" class="text-white ">Add to Cart</a></p>
							</div>
						</div>

					@endforeach
					
				</div>
				
				
			</div>
		</div>

		<div class="bg-white py-2 d-none" id="vegetable-list">
			<div class="col-md-12 p-0">
				<div class="row m-0">

					@foreach($vegetables as $data)
						<div class="card shadow  col-xl-2 col-md-3  mb-3 shadow p-0 menu-card" >
							<div>
								<img src="{{asset($data->photo)}}" class="card-img-top">
							</div>
							<div class="card-body text-center" style="padding: 5px;">
								<h4>{{$data->name}}</h4>
								<h4>Price: <span class="text-warning">{{$data->price}}K<span></h4>
								
							</div>
							<div class="card-footer bg-gradient-primary text-white addtocard" data-id="{{$data->id}}" data-name="{{$data->name}}" data-price="{{$data->price}}" data-photo="{{$data->photo}}" data-category="{{$data->category->name}}">
								<p class="text-center m-0"><a href="heo.html" onclick="return false;" class="text-white ">Add to Cart</a></p>
							</div>
						</div>

					@endforeach
					
				</div>
				
				
			</div>
		</div>
	
</div>






@endsection
@section('script')
<script type="text/javascript">
		$(document).ready(function(){
	getCountMenu();

	
})
function getCountMenu(){
	$.get('/menus/count',function(response){
		$.each(response.data,function(i,v){
			$(`.${v.name}-backend-count`).html(v.meats_count);
		})

		$.each(response.lastdate,function(i,v){
			//console.log(v[0].category.name);
			$(`.${v[0].category.name}-latestUpdate`).html(v[0].created_at);
		})
	})
}
</script>
@endsection
