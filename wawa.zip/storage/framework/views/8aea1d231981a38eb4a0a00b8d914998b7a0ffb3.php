;
<?php $__env->startSection('card'); ?>
<div class="header-body">
          <!-- Card stats -->
          <div class="row">
            <div class="col-xl-3 col-lg-6">
              <div class="card card-stats mb-4 mb-xl-0">
                <div class="card-body">
                  <div class="row">
                    <div class="col">
                      <h5 class="card-title text-uppercase text-muted mb-0">Curry</h5>
                      <span class="h2 font-weight-bold mb-0">350,897</span>
                    </div>
                    <div class="col-auto">
                      <div class="icon icon-shape bg-danger text-white rounded-circle shadow">
                       <img src="<?php echo e(asset('template/assets/img/hotpot/curry.png')); ?>" class="img-fluid" height="30" width="30">
                      </div>
                    </div>
                  </div>
                  <p class="mt-3 mb-0 text-muted text-sm">
                    <span class="text-success mr-2"><i class="fa fa-arrow-up"></i> 3.48%</span>
                    <span class="text-nowrap">Since last month</span>
                  </p>
                </div>
              </div>
            </div>
            <div class="col-xl-3 col-lg-6">
              <div class="card card-stats mb-4 mb-xl-0">
                <div class="card-body">
                  <div class="row">
                    <div class="col">
                      <h5 class="card-title text-uppercase text-muted mb-0">
                      	Meat
                      </h5>
                      <span class="h2 font-weight-bold mb-0">2,356</span>
                    </div>
                    <div class="col-auto">
                      <div class="icon icon-shape bg-warning text-white rounded-circle shadow">
                      	<img src="<?php echo e(asset('template/assets/img/hotpot/meat.png')); ?>" class="img-fluid" height="30" width="30">
                      </div>
                    </div>
                  </div>
                  <p class="mt-3 mb-0 text-muted text-sm">
                    <span class="text-danger mr-2"><i class="fas fa-arrow-down"></i> 3.48%</span>
                    <span class="text-nowrap">Since last week</span>
                  </p>
                </div>
              </div>
            </div>
            <div class="col-xl-3 col-lg-6">
              <div class="card card-stats mb-4 mb-xl-0">
                <div class="card-body">
                  <div class="row">
                    <div class="col">
                      <h5 class="card-title text-uppercase text-muted mb-0">
                      	Sea food
                      </h5>
                      <span class="h2 font-weight-bold mb-0">924</span>
                    </div>
                    <div class="col-auto">
                      <div class="icon icon-shape bg-info text-white rounded-circle shadow">
                        <img src="<?php echo e(asset('template/assets/img/hotpot/seafood.png')); ?>" class="img-fluid" height="30" width="30">
                      </div>
                    </div>
                  </div>
                  <p class="mt-3 mb-0 text-muted text-sm">
                    <span class="text-warning mr-2"><i class="fas fa-arrow-down"></i> 1.10%</span>
                    <span class="text-nowrap">Since yesterday</span>
                  </p>
                </div>
              </div>
            </div>
            <div class="col-xl-3 col-lg-6">
              <div class="card card-stats mb-4 mb-xl-0">
                <div class="card-body">
                  <div class="row">
                    <div class="col">
                      <h5 class="card-title text-uppercase text-muted mb-0">
                      	Vegeatable
                      </h5>
                      <span class="h2 font-weight-bold mb-0">49,65%</span>
                    </div>
                    <div class="col-auto">
                      <div class="icon icon-shape bg-yellow text-white rounded-circle shadow">
                        <img src="<?php echo e(asset('template/assets/img/hotpot/vegetable.png')); ?>" class="img-fluid" height="30" width="30">
                      </div>
                    </div>
                  </div>
                  <p class="mt-3 mb-0 text-muted text-sm">
                    <span class="text-success mr-2"><i class="fas fa-arrow-up"></i> 12%</span>
                    <span class="text-nowrap">Since last month</span>
                  </p>
                </div>
              </div>
            </div>


          </div>
        </div>


        <!-- meat card start -->
        <div class="container-fluid card bg-secondary shadow mt-3">
          <div class="row">

            <div class="col-md-6">
               <h2 class="heading-large text-nowrap text-center mt-2">ADD NEW MEAT PLATE</h2>

               <div class="col-md-12">
                  <label class="form-control-label" for="customFileLang">
                          Photo
                        </label>
                    <div class="form-group">
                      <input type="file" name="photo" class="form-control" id="customFileLang"> 
                    </div>
                  </div>

                  <div class="col-md-12">
                    <div class="form-group">
                      <label class="form-control-label" for="input-meat-name">
                        Name
                      </label>
                      <input type="text" name="name" id="input-meat-name" class="form-control form-control-alternative" placeholder="First name" value="Pork Marlar">
                    </div>
                  </div>

                  <div class="col-md-12">
                    <div class="form-group">
                      <label class="form-control-label" for="input-price-name">Price </label>
                      <input type="text" name="price" id="input-price-name" class="form-control form-control-alternative" placeholder="Last name" value="2100">
                    </div>
                  </div>

                  <div class="col-md-12 mb-3">
                    <input type="submit"  class="form-control bg-primary text-white" name="" value="Add New!">
                  </div>

                  
                
            </div>
           
            <div class="col-md-3 p-4 offset-md-1">
                
                
              <h3>Preview of new Plate</h3>
                    <div class="card shadow">

                      <div class="card-img-top">
                         <img src="<?php echo e(asset('template/assets/img/theme/team-4-800x800.jpg')); ?>"  class="preview" width="216px" height="230px">
                       </div>
                       <h2 class="text-center mt-3 name-pre">--------</h2>
                      <h3 class="text-center price-pre">K$$$$</h3>
                      
                    </div>
                  
                
                   
                
                
            </div>

          </div>





           <!-- <div class="row">
              <div class="col-md-2 p-1 mr-3 ml-3">
               <div class="card">
                 <div class="card-img-top p-2">
                   <img src="<?php echo e(asset('template/assets/img/hotpot/vegetable.png')); ?>" class="img-fluid">
                 </div>
                <h2 class="text-center">helo world</h2>
                <h3 class="text-center">K2300</h3>
               </div>
              </div>

              <div class="col-md-2 p-1 mr-3 ml-3">
               <div class="card">
                 <div class="card-img-top p-2">
                   <img src="<?php echo e(asset('template/assets/img/hotpot/vegetable.png')); ?>" class="img-fluid">
                 </div>
                <h2 class="text-center">helo world</h2>
                <h3 class="text-center">K2300</h3>
               </div>
              </div>

              <div class="col-md-2 p-1 mr-3 ml-3">
               <div class="card">
                 <div class="card-img-top p-2">
                   <img src="<?php echo e(asset('template/assets/img/hotpot/vegetable.png')); ?>" class="img-fluid">
                 </div>
                <h2 class="text-center">helo world</h2>
                <h3 class="text-center">K2300</h3>
               </div>
              </div>


              <div class="col-md-2 p-1 mr-3 ml-3">
               <div class="card">
                 <div class="card-img-top p-2">
                   <img src="<?php echo e(asset('template/assets/img/hotpot/vegetable.png')); ?>" class="img-fluid">
                 </div>
                <h2 class="text-center">helo world</h2>
                <h3 class="text-center">K2300</h3>
               </div>
              </div>

              <div class="col-md-2 p-1 mr-3 ml-3">
               <div class="card">
                 <div class="card-img-top p-2">
                   <img src="<?php echo e(asset('template/assets/img/hotpot/vegetable.png')); ?>" class="img-fluid">
                 </div>
                <h2 class="text-center">helo world</h2>
                <h3 class="text-center">K2300</h3>
               </div>
              </div>


              <div class="col-md-2 p-1 mr-3 ml-3">
               <div class="card">
                 <div class="card-img-top p-2">
                   <img src="<?php echo e(asset('template/assets/img/hotpot/vegetable.png')); ?>" class="img-fluid">
                 </div>
                <h2 class="text-center">helo world</h2>
                <h3 class="text-center">K2300</h3>
               </div>
              </div>

              <div class="col-md-2 p-1 mr-3 ml-3">
               <div class="card">
                 <div class="card-img-top p-2">
                   <img src="<?php echo e(asset('template/assets/img/hotpot/vegetable.png')); ?>" class="img-fluid">
                 </div>
                <h2 class="text-center">helo world</h2>
                <h3 class="text-center">K2300</h3>
               </div>
              </div>

              <div class="col-md-2 p-1 mr-3 ml-3">
               <div class="card">
                 <div class="card-img-top p-2">
                   <img src="<?php echo e(asset('template/assets/img/hotpot/vegetable.png')); ?>" class="img-fluid">
                 </div>
                <h2 class="text-center">helo world</h2>
                <h3 class="text-center">K2300</h3>
               </div>
              </div>
           </div> -->
        </div>
        <!-- meat card end -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script type="text/javascript">
  $(document).ready(function(){
    $('input[name="photo"]').change(function(){
      // alert('h');
      var reader=new FileReader();
      reader.onload=(e)=>{
        $('.preview').attr('src',e.target.result);
      }
      reader.readAsDataURL(this.files[0]); 
    })

    $('input[name="name"]').change(function(){
      var name=$(this).val();
      $('.name-pre').html(name);
    })

    $('input[name="price"]').change(function(){
      var name=$(this).val();
      $('.price-pre').html('K'+name);
    })
  })
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend/backend_template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/myprj/SarKyiTal-hotpot/resources/views/backend/menu/menu_list.blade.php ENDPATH**/ ?>