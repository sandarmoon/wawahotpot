<?php $__env->startSection('content'); ?>

<div class="container-fluid bg-white">

		<div class="bg-white py-2 " id="curry-list">
			<div class="col-md-12 p-0">
				<div class="row m-0">

					<?php $__currentLoopData = $currys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<div class="card shadow col-xl-2 col-md-3  mb-3 shadow p-0 menu-card" >
							<div>
								<img src="<?php echo e(asset($data->photo)); ?>" class="card-img-top">
							</div>
							<div class="card-body text-center" style="padding: 5px;">
								<h4><?php echo e($data->name); ?></h4>
								<h4>Price: <span class="text-warning"><?php echo e($data->price); ?>K<span></h4>
								
							</div>
							<div class="card-footer bg-gradient-primary text-white addtocard" data-id="<?php echo e($data->id); ?>" data-name="<?php echo e($data->name); ?>" data-price="<?php echo e($data->price); ?>" data-photo="<?php echo e($data->photo); ?>" data-category="<?php echo e($data->category->name); ?>">
								<p class="text-center m-0"><a href="heo.html" onclick="return false;" class="text-white ">Add to Cart</a></p>
							</div>
						</div>

					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					
				</div>
				
				
			</div>
		</div>

		<div class="bg-white py-2 d-none" id="meat-list">
			<div class="col-md-12 p-0">
				<div class="row m-0">

					<?php $__currentLoopData = $meats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<div class="card shadow col-xl-2 col-md-3  mb-3 shadow p-0 menu-card" >
							<div>
								<img src="<?php echo e(asset($data->photo)); ?>" class="card-img-top">
							</div>
							<div class="card-body text-center" style="padding: 5px;">
								<h4><?php echo e($data->name); ?></h4>
								<h4>Price: <span class="text-warning"><?php echo e($data->price); ?>K<span></h4>
								
							</div>
							<div class="card-footer bg-gradient-primary text-white addtocard" data-id="<?php echo e($data->id); ?>" data-name="<?php echo e($data->name); ?>" data-price="<?php echo e($data->price); ?>" data-photo="<?php echo e($data->photo); ?>" data-category="<?php echo e($data->category->name); ?>">
								<p class="text-center m-0"><a href="heo.html" onclick="return false;" class="text-white ">Add to Cart</a></p>
							</div>
						</div>

					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					
				</div>
				
				
			</div>
		</div>

		<div class="bg-white py-2 d-none" id="seafood-list">
			<div class="col-md-12 p-0">
				<div class="row m-0">

					<?php $__currentLoopData = $seafoods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<div class="card shadow col-xl-2 col-md-3  mb-3 shadow p-0 menu-card" >
							<div>
								<img src="<?php echo e(asset($data->photo)); ?>" class="card-img-top">
							</div>
							<div class="card-body text-center" style="padding: 5px;">
								<h4><?php echo e($data->name); ?></h4>
								<h4>Price: <span class="text-warning"><?php echo e($data->price); ?>K<span></h4>
								
							</div>
							<div class="card-footer bg-gradient-primary text-white addtocard" data-id="<?php echo e($data->id); ?>" data-name="<?php echo e($data->name); ?>" data-price="<?php echo e($data->price); ?>" data-photo="<?php echo e($data->photo); ?>" data-category="<?php echo e($data->category->name); ?>">
								<p class="text-center m-0"><a href="heo.html" onclick="return false;" class="text-white ">Add to Cart</a></p>
							</div>
						</div>

					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					
				</div>
				
				
			</div>
		</div>

		<div class="bg-white py-2 d-none" id="vegetable-list">
			<div class="col-md-12 p-0">
				<div class="row m-0">

					<?php $__currentLoopData = $vegetables; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<div class="card shadow  col-xl-2 col-md-3  mb-3 shadow p-0 menu-card" >
							<div>
								<img src="<?php echo e(asset($data->photo)); ?>" class="card-img-top">
							</div>
							<div class="card-body text-center" style="padding: 5px;">
								<h4><?php echo e($data->name); ?></h4>
								<h4>Price: <span class="text-warning"><?php echo e($data->price); ?>K<span></h4>
								
							</div>
							<div class="card-footer bg-gradient-primary text-white addtocard" data-id="<?php echo e($data->id); ?>" data-name="<?php echo e($data->name); ?>" data-price="<?php echo e($data->price); ?>" data-photo="<?php echo e($data->photo); ?>" data-category="<?php echo e($data->category->name); ?>">
								<p class="text-center m-0"><a href="heo.html" onclick="return false;" class="text-white ">Add to Cart</a></p>
							</div>
						</div>

					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					
				</div>
				
				
			</div>
		</div>
	
</div>






<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script type="text/javascript">
		$(document).ready(function(){
	getCountMenu();

	
})
function getCountMenu(){
	$.get('/menus/count',function(response){
		$.each(response.data,function(i,v){
			$(`.${v.name}-backend-count`).html(v.meats_count);
		})

		$.each(response.lastdate,function(i,v){
			//console.log(v[0].category.name);
			$(`.${v[0].category.name}-latestUpdate`).html(v[0].created_at);
		})
	})
}
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend/front_template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/myprj/SarKyiTal-hotpot/resources/views/frontend/homepage.blade.php ENDPATH**/ ?>