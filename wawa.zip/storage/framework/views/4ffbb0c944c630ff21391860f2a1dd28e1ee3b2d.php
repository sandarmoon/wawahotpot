<?php $__env->startSection('content'); ?>
<div class="container-fluid bg-white">
	<h2>shello world</h2>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend/front_template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/myprj/SarKyiTal-hotpot/resources/views/frontend/home.blade.php ENDPATH**/ ?>